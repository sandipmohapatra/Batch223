
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.Iterator;
import org.junit.jupiter.api.Test;
import in.nit.Maths;
public class TestMock {
	@Test
	public void testMockA() {
		int a=10,b=20;
		Maths m=mock(Maths.class);
		when(m.add(a, b)).thenReturn(a+b);
		assertEquals(30, m.add(a, b));
	}
	@Test
	public void testMockB() {
		Iterator<String> itr=mock(Iterator.class);
		when(itr.next()).thenReturn("One").thenReturn("Two");
		String actual=itr.next()+" "+itr.next();
		assertEquals("One Two", actual);
	}
	@Test
	public void testMockC() {
		Comparable<String> comp=mock(Comparable.class);
		when(comp.compareTo("RAGHU")).thenReturn(10);
		when(comp.compareTo("SIR")).thenReturn(20);
		assertEquals(10, comp.compareTo("RAGHU"));
	}
}
