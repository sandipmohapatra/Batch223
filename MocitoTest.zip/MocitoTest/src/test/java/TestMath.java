
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import in.nit.Maths;
import in.nit.service.ProductCatalog;
@DisplayName("Test Maths Operations")
@TestMethodOrder(OrderAnnotation.class)
public class TestMath {
	@Mock
	private Maths m;
	private ProductCatalog pc;
	private int a,b;
	String expected,actual;
	@BeforeEach
	public void doSetup() {
		MockitoAnnotations.initMocks(this);
		expected="Hello Data is:"+(a+b);
	}
	@DisplayName("Test Add One")
	@Test
	@Order(4)
	public void testAdd() {
		when(m.add(a, b)).thenReturn(a+b);
		int actual=m.add(a, b);
		assertEquals(a+b, actual);
	}
	@DisplayName("Test Add Two")
	@Test
	@Order(2)
	@Disabled
	public void testAddService()
	{
		when(m.add(a, b)).thenReturn(a+b);
		pc=new ProductCatalog(m);
		actual=pc.getMsg(10, 20);
		assertEquals(expected, actual);
	}
	@AfterEach
	public void close() {
		m=null;
	}
}