package in.nit;
public interface Maths {
public int add(int a,int b) ;
}