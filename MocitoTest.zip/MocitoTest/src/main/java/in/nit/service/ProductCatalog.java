package in.nit.service;
import in.nit.Maths;
public class ProductCatalog {
private Maths m;
public ProductCatalog(Maths m) {
this.m=m;
}
public String getMsg(int len,int wid) {
return "Hello Data is:"+m.add(len, wid);
}
}